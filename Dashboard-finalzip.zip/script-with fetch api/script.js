// Function to simulate fetching data from an API
function fetchData() {
    return new Promise((resolve) => {
        setTimeout(() => {
            // Simulated fetched data
            const data = {
                labels: ['October', 'November', 'December'], // Dynamic labels
                revenue: {
                    currentYear: [800000, 900000, 1000000],
                    previousYear: [600000, 700000, 800000]
                },
                newCustomers: {
                    currentYear: [100, 100, 109],
                    previousYear: [80, 90, 100]
                },
                avgRevenue: {
                    currentYear: [1900, 2100, 2200],
                    previousYear: [1500, 1800, 2000]
                },
                cac: {
                    currentYear: [350, 370, 400],
                    previousYear: [300, 320, 350]
                }
            };
            resolve(data);
        }, 1000); // Simulate a delay of 1 second
    });
}

// Function to initialize charts
async function initializeCharts() {
    const data = await fetchData();

    // Initialize Revenue Chart
    var ctxRevenue = document.getElementById('revenueChart').getContext('2d');
    var revenueChart = new Chart(ctxRevenue, {
        type: 'bar',
        data: {
            labels: data.labels, // Using dynamic labels
            datasets: [{
                label: 'Current Year',
                data: data.revenue.currentYear,
                backgroundColor: '#FF9999',
                borderColor: '#FF6666',
                borderWidth: 1
            }, {
                label: 'Previous Year',
                data: data.revenue.previousYear,
                backgroundColor: '#FFCC99',
                borderColor: '#FF9966',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Initialize New Customers Chart
    var ctxCustomers = document.getElementById('customersChart').getContext('2d');
    var customersChart = new Chart(ctxCustomers, {
        type: 'bar',
        data: {
            labels: data.labels, // Using dynamic labels
            datasets: [{
                label: 'Current Year',
                data: data.newCustomers.currentYear,
                backgroundColor: '#66CCCC',
                borderColor: '#33CCCC',
                borderWidth: 1
            }, {
                label: 'Previous Year',
                data: data.newCustomers.previousYear,
                backgroundColor: '#99CCCC',
                borderColor: '#66CCCC',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Initialize Avg Revenue per Customer Chart
    var ctxAvgRevenue = document.getElementById('avgRevenueChart').getContext('2d');
    var avgRevenueChart = new Chart(ctxAvgRevenue, {
        type: 'bar',
        data: {
            labels: data.labels, // Using dynamic labels
            datasets: [{
                label: 'Current Year',
                data: data.avgRevenue.currentYear,
                backgroundColor: '#CC9999',
                borderColor: '#CC6666',
                borderWidth: 1
            }, {
                label: 'Previous Year',
                data: data.avgRevenue.previousYear,
                backgroundColor: '#FFCCCC',
                borderColor: '#FF9999',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Initialize Customer Acquisition Cost Chart
    var ctxCAC = document.getElementById('cacChart').getContext('2d');
    var cacChart = new Chart(ctxCAC, {
        type: 'bar',
        data: {
            labels: data.labels, // Using dynamic labels
            datasets: [{
                label: 'Current Year',
                data: data.cac.currentYear,
                backgroundColor: '#FFCC66',
                borderColor: '#FF9966',
                borderWidth: 1
            }, {
                label: 'Previous Year',
                data: data.cac.previousYear,
                backgroundColor: '#FFCC99',
                borderColor: '#FF9966',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Call the initializeCharts function to fetch data and create charts
initializeCharts();
